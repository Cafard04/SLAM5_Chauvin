package com.example.newlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DetailsActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        setTitle(getLocalClassName());

        Button button1 = findViewById(R.id.button_ok);
        button1.setOnClickListener(this);

        NewsListApplication app = (NewsListApplication) getApplicationContext();
        TextView txtV = findViewById(R.id.textViewDet);
        txtV.setText(app.getLogin());


    }


    public void onClick(View v) {
        switch(v.getId()) {

            case R.id.button_ok:
                Intent i = new Intent(this, NewsActivity.class);
                startActivity(i);
                break;

        }
    }


}