package com.example.newlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{




        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            setTitle(getLocalClassName());

            Button button1 = (Button) findViewById(R.id.button1);
            button1.setOnClickListener(this);

            NewsListApplication app = (NewsListApplication) getApplicationContext();
            String login = app.getLogin();
        }

        @Override
        public void onClick(View v) {
            switch(v.getId()) {
                case R.id.button1:
                    Intent intent =new Intent(this, NewsActivity.class);
                    EditText txt = findViewById(R.id.editText_login);
                    intent.putExtra("login", txt.getText().toString());
                    startActivity(intent);

                    NewsListApplication app = (NewsListApplication) getApplicationContext();
                    app.setLogin(txt.getText().toString());

                    break;

            }
        }
    }