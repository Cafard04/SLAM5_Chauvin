package com.example.newlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class NewsActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        setTitle(getLocalClassName());

        Button button1 = findViewById(R.id.buttondet);
        button1.setOnClickListener(this);
        Button button2 = findViewById(R.id.buttonlogout);
        button2.setOnClickListener(this);
        Button button3 = findViewById(R.id.buttonbacka);
        button3.setOnClickListener(this);
        Button button4 = findViewById(R.id.buttonabout);
        button4.setOnClickListener(this);

        Intent iTxt = getIntent();
        TextView txtV = findViewById(R.id.textView);
        txtV.setText(iTxt.getStringExtra("login"));

    }


    public void onClick(View v) {
        switch(v.getId()) {

            case R.id.buttonbacka:
                finishAffinity();
                break;

            case R.id.buttondet:
                Intent i = new Intent(this, DetailsActivity.class);
                startActivity(i);
                break;
            case R.id.buttonlogout:
                Intent ia = new Intent(this, MainActivity.class);
                startActivity(ia);
                break;
            case R.id.buttonabout:
                String url ="https://perso.univ-rennes1.fr/pierre.nerzic/Android";
                Intent intent =new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                break;

        }
    }


    private static final String TAG ="NewsList";
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i(TAG,"Terminaison de l 'activité "+getLocalClassName());
    }




}