package com.example.sqlite_td6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class modify extends AppCompatActivity  implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        Intent iTxt = getIntent();
        TextView txtV = findViewById(R.id.inputModNom);
        TextView txtV2 = findViewById(R.id.inputModTel);
        TextView txtV3 = findViewById(R.id.ViewId);
        txtV2.setText(iTxt.getStringExtra("tel"));
        txtV.setText(iTxt.getStringExtra("nom"));
        txtV3.setText(String.valueOf(iTxt.getStringExtra("_id")));

        Button buttonMod = (Button) findViewById(R.id.buttonMod);
        buttonMod.setOnClickListener((View.OnClickListener) this);
        Log.d("rerererererere",""+txtV3.getText().toString());

    }
    public void onClick(View v) {
        LeDatabaseHandler db = new LeDatabaseHandler(this);
        SQLiteDatabase SQLiteDatabase = db.getReadableDatabase();



        switch(v.getId()) {
            case R.id.buttonMod:

                Intent intent =new Intent(this, Choice.class);
                EditText txt = findViewById(R.id.inputModNom);
                EditText txt2 = findViewById(R.id.inputModTel);
                EditText txt3 = findViewById(R.id.ViewId);
                //TextView txtV3 = findViewById(R.id.ViewId);
                Log.d("e","gdgdgdtgtgrtgr");
                db.updateContact(txt.getText().toString(), txt2.getText().toString(),Integer.parseInt(txt3.getText().toString()));
                Log.d("eeee",""+txt.getText().toString()+txt3.getText().toString());
                startActivity(intent);


                break;

        }
    }

}


