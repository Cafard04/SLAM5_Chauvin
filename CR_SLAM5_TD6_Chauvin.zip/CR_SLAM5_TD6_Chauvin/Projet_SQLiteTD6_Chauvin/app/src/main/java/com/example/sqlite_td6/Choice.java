package com.example.sqlite_td6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.List;

import static com.example.sqlite_td6.MainActivity.ArrayofName;

public class Choice extends AppCompatActivity {

    private ListView oListView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);

        final LeDatabaseHandler db = new LeDatabaseHandler(this);
        oListView = (ListView) findViewById(R.id.listViewIni);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Choice.this,
            android.R.layout.simple_list_item_1, ArrayofName);
         oListView.setAdapter(adapter);

         Log.d("liste",""+ArrayofName.size());

        oListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                List<Contact> contacts = db.getAllContact();
                Intent intent = new Intent(Choice.this, modify.class);
                intent.putExtra("nom", contacts.get(position).getNom());
                intent.putExtra("tel", contacts.get(position).getNumTelephone());
                intent.putExtra("_id", String.valueOf(contacts.get(position).getId()));

                Log.i( "NOMM:" ,""+contacts.get(position).getId());

                startActivity(intent);

            }

            });
    }

}