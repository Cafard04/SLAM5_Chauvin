package com.example.sqlite_td6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;

import java.util.List;

public class Liste extends MainActivity {

    private ListView mListView;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste);
        LeDatabaseHandler db = new LeDatabaseHandler(this);
        SQLiteDatabase SQLiteDatabase = db.getReadableDatabase();
        //db.insertContact(contact);

        Log.d("JMF", "Lecture des Contacts");
        List<Contact> contacts = db.getAllContact();

       Log.d("taille",""+contacts.size());




               //db.insertContact(new Contact("1",iTxt.getStringExtra("nom"), iTxt.getStringExtra("tel")));

    }
}