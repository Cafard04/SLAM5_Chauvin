package com.example.sqlite_td6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class LeDatabaseHandler extends SQLiteOpenHelper {

    private static SQLiteDatabase db;
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "contactsManager";
    private static final String TABLE_CONTACTS = "contacts";
    private static final int KEY_ID = 0;
    private static final String KEY_NAME = "name";
    private static final String KEY_PH_NO = "phone_number";


    public LeDatabaseHandler(Context context){
        super(context, DATABASE_NAME,null,DATABASE_VERSION);
        db = this.getWritableDatabase();
    }
   /* public LeDatabaseHandler(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        db = this.getWritableDatabase();
    }
*/

    private static final String TABLE_CONTATCS = "contacts";
    private static final String COLONNE_ID= "_id";
    private static final String COLONNE_NOM = "nom";
    private static final String COLONNE_TEL = "numTelephone";


    private static final String REQUETE_CREATION_TABLE = "create table "
            + TABLE_CONTATCS + " (" + COLONNE_ID
            + " integer primary key autoincrement, " + COLONNE_NOM
            + " varchar(30) not null, " + COLONNE_TEL + " varchar(30) not null);";



    public long insertContact(Contact contact) {
        ContentValues valeurs = new ContentValues();
        valeurs.put(COLONNE_NOM, contact.getNom());
        valeurs.put(COLONNE_TEL, contact.getNumTelephone());
        return db.insert(TABLE_CONTATCS, null, valeurs);
    }


    public List<Contact> getAllContact()
    {
        List<Contact> contacts = new ArrayList<Contact>();
        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Contact contact = new Contact(0,"","");
                contact.setId(Integer.parseInt(cursor.getString(0)));
                //contact.setId(cursor.getString(0));
                contact.setNom(cursor.getString(1));
                contact.setNumTelephone(cursor.getString(2));

                contacts.add(contact);
            } while (cursor.moveToNext());
        }

    return contacts;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(REQUETE_CREATION_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("create table " + TABLE_CONTATCS + ";");
        onCreate(db);
    }

    public void clearDatabase(List<Contact> TABLE_NAME) {
        String clearDBQuery = "DELETE FROM "+TABLE_CONTATCS;
        db.execSQL(clearDBQuery);
    }

    public boolean updateContact(String s, String s1, int s2) {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("UPDATE "+TABLE_CONTACTS+" SET nom = "+"'"+s+"' "+ "," +
                " numTelephone="+"'"+s1+"' "+ "WHERE _id = "+"'"+s2+"'");
        return true;
    }


}
