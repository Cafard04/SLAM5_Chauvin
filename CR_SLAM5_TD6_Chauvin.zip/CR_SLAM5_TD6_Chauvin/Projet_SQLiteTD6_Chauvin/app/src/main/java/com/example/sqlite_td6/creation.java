package com.example.sqlite_td6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class creation extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creation);

        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener((View.OnClickListener) this);


    }

    public void onClick(View v) {
        LeDatabaseHandler db = new LeDatabaseHandler(this);
        SQLiteDatabase SQLiteDatabase = db.getReadableDatabase();

        switch(v.getId()) {
            case R.id.button1:
                Intent intent =new Intent(this, MainActivity.class);
                EditText txt = findViewById(R.id.input1);
                EditText txt2 = findViewById(R.id.input2);
                db.insertContact(new Contact(0,txt.getText().toString(), txt2.getText().toString()));
                startActivity(intent);


                break;

        }
    }

}