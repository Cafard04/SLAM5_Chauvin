package com.example.sqlite_td6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    private ListView oListView;
    private String[] choix = new String[]{
            "Afficher tout vos contacts", "Créer un contact",
            "Modifier un contact", "Initialiser la base"
    };
    public static ArrayList<String> ArrayofName = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final LeDatabaseHandler db = new LeDatabaseHandler(this);

        mListView = (ListView) findViewById(R.id.listView);
        oListView = (ListView) findViewById(R.id.listViewIni);

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, choix);
        mListView.setAdapter(adapter);


        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    setContentView(R.layout.activity_liste);
                    List<Contact> contacts = db.getAllContact();
                    TableLayout tableLayout = (TableLayout)findViewById(R.id.tableLayoutListe);
                    for (Contact cn : contacts){
                        TableRow row = new TableRow(MainActivity.this);
                        TextView tNom = new TextView(MainActivity.this);
                        TextView tNum = new TextView(MainActivity.this);
                        tNom.setText(cn.getNom());
                        tNum.setText(cn.getNumTelephone());
                        row.addView(tNom);
                        row.addView(tNum);
                        tableLayout.addView(row,new TableLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT));
                    }


                } else if (position == 1) {
                    Intent intent = new Intent(MainActivity.this, creation.class);
                    startActivity(intent);
                } else if(position==2){
                    Intent intent = new Intent(MainActivity.this, Choice.class);
                    startActivity(intent);

                } else if (position == 3) {
                    ListView listView = (ListView) findViewById(R.id.listView);
                    List<Contact> contacts = db.getAllContact();
                    db.clearDatabase(contacts);
                    SQLiteDatabase SQLiteDatabase = db.getReadableDatabase();

                    db.insertContact(new Contact(1, "Jo", "9100000000"));
                    db.insertContact(new Contact(2, "Jack", "9199999999"));
                    db.insertContact(new Contact(3, "William", "9522222222"));
                    db.insertContact(new Contact(4, "Averel", "9533333333"));

                    Log.d("JMF", "Lecture des Contacts");
                    contacts = db.getAllContact();

                    Log.d("Bla22",""+contacts.size());
                        for (Contact cn : contacts) {
                        String log = "Id: " + cn.getId() + " ,Name: " + cn.getNom() + " ,Phone: "
                                + cn.getNumTelephone();
                        ArrayofName.add(cn.getNom());
                        Log.d("JMF", log);
                    }

                }

            }

    });

}

}
