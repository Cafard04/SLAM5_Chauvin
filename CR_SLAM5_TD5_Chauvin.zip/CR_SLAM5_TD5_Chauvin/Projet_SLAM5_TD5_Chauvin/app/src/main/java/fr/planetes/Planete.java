package fr.planetes;


public class Planete
{
    private String nom;
    private int distance;
    private int idImage;
    private float rBar;


    Planete(String nom, int distance, int idimage, float rBar)
    {
        this.nom = nom;
        this.distance = distance;
        this.idImage = idimage;
        this.rBar = rBar;
    }

    public Planete()
    {
        this.nom = "INCONNU";
        this.distance = 0;
        this.idImage = R.drawable.morte;
    }

    public String toString()
    {
        return "Planètes : "+ nom + "("+distance+")";
    }

    public String getNom()
    {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public int getDistance()
    {
        return distance;
    }

    public void setDistance(int distance)
    {
        this.distance = distance;
    }

    public int getIdImage()
    {
        return idImage;
    }

    public void setIdImage(int idImage)
    {
        this.idImage = idImage;
    }

    public float getRating()
    {
        return rBar;
    }

    public void setRating(float rBar)
    {
        this.rBar = rBar;
    }






};
