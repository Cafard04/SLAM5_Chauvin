package fr.planetes;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class EditActivity extends Activity
{
    /** identifiant de l'item en cours d'édition */
    private int identifiant;

    // contenu du layout
    private ImageView ivImage;
    private EditText etNom;
    private EditText etDistance;
    private RatingBar etrBar;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // mettre en place l'interface
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_activity);
        findViews();

        Intent intent = getIntent();
        identifiant = intent.getIntExtra("position", -1);


        // changer le titre de la fenêtre selon qu'on édite ou qu'on crée un item
        if (identifiant < 0) {

            //listaddplanete
            setTitle(R.string.nouveau);
        } else {
            setTitle(R.string.edit);
        }

        // afficher les informations éditables (nom,distance) de la planète
        setItem();



    }

    /**
     * cherche les objets Java correspondant aux vues
     */
    private void findViews()
    {
        ivImage = (ImageView) findViewById(R.id.item_planete_image);
        etNom = (EditText) findViewById(R.id.item_planete_nom);
        etDistance = (EditText) findViewById(R.id.item_planete_distance_nb);
        etrBar = (RatingBar) findViewById(R.id.item_planete_habitabilite);
    }


    /**
     * Affiche l'item dans les vues de this
     */
    public void setItem()
    {
        // si l'identifiant est invalide, alors sortir de la fonction (aucun item à afficher)
        if (identifiant < 0) return;

        // récupérer l'item désigné par l'identifiant
        PlanetesApplication app = (PlanetesApplication) getApplicationContext();
        ArrayList<Planete> liste = app.getListe();
        Planete planete = liste.get(identifiant);

        // afficher ses valeurs dans les vues
        etNom.setText(planete.getNom());
        etDistance.setText(String.valueOf(planete.getDistance()));
        ivImage.setImageResource(planete.getIdImage());
        etrBar.setRating(planete.getRating());
    }

    /**
     * Affecte les propriétés de l'item avec ce qu'il y a dans les vues
     */

    public void onValider()
    {
        PlanetesApplication app = (PlanetesApplication) getApplicationContext();
        ArrayList<Planete> liste = app.getListe();



        Planete planete = new Planete();

     if (identifiant < 0) {
            liste.add(planete);
        } else {
            liste.set(identifiant,planete);
        }

        // item concerné par l'activité d'édition


        // FIXME si l'identifiant est -1, alors il faut créer l'item, sinon il faut le prendre dans la liste de l'application


        // récupérer les valeurs présentes dans les vues
        planete.setNom(etNom.getText().toString());
        planete.setDistance(Integer.parseInt(etDistance.getText().toString()));
        planete.setRating(etrBar.getRating());
        // on ne peut pas màj l'image, il faut faire autrement mais ce n'est pas demandé

        // TODO trier la liste sur la distance des planètes
        //app.sortListe();
    }


    /*** Gestion du menu de la barre d'action en haut à droite ***/

    /**
     * appelée pour créer le menu de l'activité
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.edit, menu);
        return true;
    }

    /**
     * appelée quand on clique sur un élément de menu
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId()) {
        case R.id.valider:
            // l'utilisateur a choisi le menu valider : l'activité se termine avec succès
            onValider();
            setResult(RESULT_OK);           // cf onActivityResult dans MainActivity
            finish();
            return true;

        case R.id.annuler:
            // l'utilisateur a choisi le menu annuler : l'activité se termine en échec
            setResult(RESULT_CANCELED);     // cf onActivityResult dans MainActivity
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
